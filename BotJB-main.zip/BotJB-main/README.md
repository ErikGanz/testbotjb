# Drawl Nag
Simple WhatsApp Bot

### JB STORE
# INSTALL HERE 👇
```bash
> pkg update && pkg upgrade
> pkg install git -y
> pkg install nodejs -y
> pkg install ffmpeg -y
> pkg install imagemagick -y
```
###### Run
```bash
> node . [<session name>] (session name is optional)
```

---------

### FOR WINDOWS/VPS/RDP USER
* Download And Install Git [`Click Here`](https://git-scm.com/downloads) <br>
* Download And Install NodeJS [`Click Here`](https://nodejs.org/en/download) <br>
* Download And Install FFMPEG [`Click Here`](https://ffmpeg.org/download.html) (don't forget to path) 
* Download And Install ImageMagick [`Click Here`](https://imagemagick.org/script/download.php) (if nulis want work,  checklist columns 1,2,3,5,6) 
```bash
> npm install
```
###### Run
```bash
> node index.js
```
--------------

##### Powered By : [`XTEAM`](https://api.xteam.xyz) 
##### Author / Creator : [`Drawl Nag`](https://GitHub.com/Arya274) 
##### WA JB STORE : [`Jb Store`](Wa.me/6283819654409)
